package com.saqibstudio.statussaver.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import com.anggrayudi.storage.file.toRawFile
import com.saqibstudio.statussaver.R
import com.saqibstudio.statussaver.models.MEDIA_TYPE_IMAGE
import com.saqibstudio.statussaver.models.MEDIA_TYPE_VIDEO
import com.saqibstudio.statussaver.models.MediaModel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

fun Context.isStatusExist(fileName: String): Boolean {
    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    val file = File("${downloadDir}/${getString(R.string.app_name)}", fileName)
    return file.exists()
}


fun getFileExtension(fileName: String): String {
    val lastDotIndex = fileName.lastIndexOf(".")

    if (lastDotIndex >= 0 && lastDotIndex < fileName.length - 1) {
        return fileName.substring(lastDotIndex + 1)
    }
    return ""
}

fun Context.saveStatus(model: MediaModel): Boolean {
    if (isStatusExist(model.fileName)) {
        return true
    }

    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
        return saveStatusBeforeQ(this, Uri.parse(model.pathUri))
    }

    val extension = getFileExtension(model.fileName)
    val mimeType = "${model.type}/$extension"

    // Validate pathUri before proceeding
    val uri = model.pathUri.toUri()
    if (contentResolver.openInputStream(uri) == null) {
        return false // File does not exist, return early
    }

    val inputStream = contentResolver.openInputStream(uri)
    try {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.DISPLAY_NAME, model.fileName)
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOCUMENTS + "/" + getString(R.string.app_name)
            )
        }
        val newUri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
        newUri?.let {
            val outputStream = contentResolver.openOutputStream(it)
            if (inputStream != null) {
                outputStream?.write(inputStream.readBytes())
            }
            outputStream?.close()
            inputStream?.close()
            return true
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return false
}


private fun saveStatusBeforeQ(context: Context, uri: Uri): Boolean {
    // converting doc file to file
    try {
        val documentFile = DocumentFile.fromTreeUri(context, uri)
        if (documentFile != null) {
            val sourceFile = documentFile.toRawFile(context)?.takeIf { f2 ->
                f2.canRead()
            }
            val destinationFile = sourceFile?.let { sourceF ->
                File(
                    "${Environment.getExternalStorageDirectory()}/Documents/${context.getString(R.string.app_name)}",
                    sourceF.name
                )
            }

            destinationFile?.let { destFile ->
                // making dirs & file
                if (!destFile.parentFile?.exists()!!) {
                    destFile.mkdirs()
                }
                if (!destFile.exists()) {
                    destFile.createNewFile()
                }

                // copying content from dest file to source file
                val source = FileInputStream(sourceFile).channel
                val destination = FileOutputStream(destFile).channel

                destination.transferFrom(source, 0, source.size())
                source.close()
                destination.close()


                return true

            }
        }
        return false
    } catch (e: Exception) {
        e.printStackTrace()
        return false
    }
}

fun Context.getSavedStatuses(): List<MediaModel> {
    val savedList = ArrayList<MediaModel>()
    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    val appDir = File(downloadDir, getString(R.string.app_name))

    appDir.listFiles()?.forEach { file ->
        if (file.isFile) {
            savedList.add(
                MediaModel(
                    pathUri = file.toUri().toString(), // FIX: Ensuring correct URI format
                    fileName = file.name,
                    type = if (file.extension == "mp4") MEDIA_TYPE_VIDEO else MEDIA_TYPE_IMAGE,
                    isDownloaded = true,
                    isSavedStatus = true
                )
            )
        }
    }
    return savedList
}


fun Context.deleteSavedStatus(fileName: String): Boolean {
    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    val file = File("${downloadDir}/${getString(R.string.app_name)}", fileName)
    return if (file.exists()) {
        file.delete()
    } else false
}














