package com.saqibstudio.statussaver.data

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.MutableLiveData
import com.saqibstudio.statussaver.models.MEDIA_TYPE_IMAGE
import com.saqibstudio.statussaver.models.MEDIA_TYPE_VIDEO
import com.saqibstudio.statussaver.models.MediaModel
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.utils.SharedPrefKeys
import com.saqibstudio.statussaver.utils.SharedPrefUtils
import com.saqibstudio.statussaver.utils.getFileExtension
import com.saqibstudio.statussaver.utils.isStatusExist
import com.saqibstudio.statussaver.utils.saveStatus

class StatusRepo(val context: Context) {

    val whatsAppStatusesLiveData = MutableLiveData<ArrayList<MediaModel>>()
    val whatsAppBusinessStatusesLiveData = MutableLiveData<ArrayList<MediaModel>>()

    val activity = context as Activity

    private val wpStatusesList = ArrayList<MediaModel>()
    private val wpBusinessStatusesList = ArrayList<MediaModel>()

    private val TAG = "StatusRepo"

    fun getAllStatuses(whatsAppType: String = Constants.TYPE_WHATSAPP_MAIN) {
        val treeUriString = when (whatsAppType) {
            Constants.TYPE_WHATSAPP_MAIN -> SharedPrefUtils.getPrefString(SharedPrefKeys.PREF_KEY_WP_TREE_URI, "")
            else -> SharedPrefUtils.getPrefString(SharedPrefKeys.PREF_KEY_WP_BUSINESS_TREE_URI, "")
        }

        if (treeUriString.isNullOrEmpty()) {
            Log.e(TAG, "getAllStatuses: treeUri is null or empty!")
            return
        }

        val treeUri = treeUriString.toUri()
        Log.d(TAG, "getAllStatuses: $treeUri")

        try {
            activity.contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            Log.e(TAG, "getAllStatuses: Failed to take URI permission", e)
            return
        }

        val fileDocument = DocumentFile.fromTreeUri(activity, treeUri)
        if (fileDocument == null) {
            Log.e(TAG, "getAllStatuses: fileDocument is null. Uri might be invalid.")
            return
        }

        fileDocument.listFiles().forEach { file ->
            val fileName = file.name ?: return@forEach  // Skip files with null names
            Log.d(TAG, "getAllStatuses: $fileName")

            if (fileName != ".nomedia" && file.isFile) {
                val isDownloaded = context.isStatusExist(fileName)
                val fileExtension = getFileExtension(fileName)
                Log.d(TAG, "getAllStatusesExtension: Extension: $fileExtension || $fileName")

                val type = if (fileExtension == "mp4") MEDIA_TYPE_VIDEO else MEDIA_TYPE_IMAGE

                val model = MediaModel(
                    pathUri = file.uri.toString(),
                    fileName = fileName,
                    type = type,
                    isDownloaded = isDownloaded
                )

                when (whatsAppType) {
                    Constants.TYPE_WHATSAPP_MAIN -> wpStatusesList.add(model)
                    else -> wpBusinessStatusesList.add(model)
                }
            }
        }

        when (whatsAppType) {
            Constants.TYPE_WHATSAPP_MAIN -> {
                Log.d(TAG, "getAllStatuses: Pushing Value to Wp live Data")
                whatsAppStatusesLiveData.postValue(wpStatusesList)
                autoSaveStatuses(wpStatusesList)
            }
            else -> {
                Log.d(TAG, "getAllStatuses: Pushing Value to Wp Business live Data")
                whatsAppBusinessStatusesLiveData.postValue(wpBusinessStatusesList)
                autoSaveStatuses(wpBusinessStatusesList)
            }
        }
    }

    private fun autoSaveStatuses(list: List<MediaModel>) {
        if (SharedPrefUtils.getPrefBoolean(SharedPrefKeys.AUTO_SAVE, false)) {
            Thread {
                list.forEach { media ->
                    if (!media.isDownloaded) {
                        val success = context.saveStatus(media)
                        if (success) {
                            media.isDownloaded = true
                            Log.d(TAG, "Auto-saved: ${media.fileName}")
                        }
                    }
                }
            }.start()
        }
    }
}
