package com.saqibstudio.statussaver.models

data class SettingsModel(
    val title:String,
    val desc:String
)