package com.saqibstudio.statussaver.views.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.saqibstudio.statussaver.R
import com.saqibstudio.statussaver.databinding.ItemMediaBinding
import com.saqibstudio.statussaver.models.MEDIA_TYPE_IMAGE
import com.saqibstudio.statussaver.models.MEDIA_TYPE_VIDEO
import com.saqibstudio.statussaver.models.MediaModel
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.utils.deleteSavedStatus
import com.saqibstudio.statussaver.utils.saveStatus
import com.saqibstudio.statussaver.views.activities.ImagesPreview
import com.saqibstudio.statussaver.views.activities.VideosPreview

class MediaAdapter(
    private var list: ArrayList<MediaModel>,
    private val context: Context,
    private val isSavedFragment: Boolean = false
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemMediaBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(media: MediaModel) {
            binding.apply {
                Glide.with(context)
                    .load(media.pathUri.toUri())
                    .into(statusImage)

                statusPlay.visibility = if (media.type == MEDIA_TYPE_VIDEO) View.VISIBLE else View.GONE

                statusDownload.setImageResource(
                    if (isSavedFragment) R.drawable.baseline_delete_24
                    else if (media.isDownloaded) R.drawable.ic_downloaded
                    else R.drawable.ic_download
                )

                cardStatus.setOnClickListener {
                    val intent = if (media.type == MEDIA_TYPE_VIDEO) {
                        Intent(context, VideosPreview::class.java)
                    } else {
                        Intent(context, ImagesPreview::class.java)
                    }
                    intent.putExtra(Constants.MEDIA_LIST_KEY, list)
                    intent.putExtra(Constants.MEDIA_SCROLL_KEY, layoutPosition)
                    intent.putExtra(Constants.FRAGMENT_TYPE_KEY, if (isSavedFragment) "saved" else "status")
                    context.startActivity(intent)
                }

                statusDownload.setOnClickListener {
                    if (isSavedFragment) {
                        showDeleteDialog(layoutPosition)
                    } else {
                        val success = context.saveStatus(media)
                        if (success) {
                            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
                            media.isDownloaded = true
                            statusDownload.setImageResource(R.drawable.ic_downloaded)
                        } else {
                            Toast.makeText(context, "Failed to Save", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ItemMediaBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int = list.size

    private fun showDeleteDialog(position: Int) {
        AlertDialog.Builder(context).apply {
            setTitle("Delete Status")
            setMessage("Are you sure you want to delete this status?")
            setPositiveButton("Delete") { _, _ ->
                val success = context.deleteSavedStatus(list[position].fileName)
                if (success) {
                    list.removeAt(position)
                    notifyItemRemoved(position)
                    Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show()
                }
            }
            setNegativeButton("Cancel", null)
        }.show()
    }

    fun updateList(newList: List<MediaModel>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
