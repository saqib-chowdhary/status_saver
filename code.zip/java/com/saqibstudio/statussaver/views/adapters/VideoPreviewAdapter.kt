package com.saqibstudio.statussaver.views.adapters

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.RecyclerView
import com.saqibstudio.statussaver.R
import com.saqibstudio.statussaver.databinding.ItemVideoPreviewBinding
import com.saqibstudio.statussaver.models.MediaModel
import com.saqibstudio.statussaver.utils.deleteSavedStatus
import com.saqibstudio.statussaver.utils.saveStatus

class VideoPreviewAdapter(
    val list: ArrayList<MediaModel>,
    val context: Context,
    private val isSavedFragment: Boolean = false
) : RecyclerView.Adapter<VideoPreviewAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemVideoPreviewBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(mediaModel: MediaModel) {
            binding.apply {
                val player = ExoPlayer.Builder(context).build()
                playerView.player = player
                val mediaItem = MediaItem.fromUri(mediaModel.pathUri)

                player.setMediaItem(mediaItem)
                player.prepare()

                if (isSavedFragment) {
                    tools.statusDownload.setImageResource(R.drawable.baseline_delete_24) // Change to delete icon
                    tools.txtSave.setText("Delete")
                    tools.download.setOnClickListener {
                        val success = context.deleteSavedStatus(mediaModel.fileName)
                        if (success) {
                            list.removeAt(adapterPosition)
                            notifyItemRemoved(adapterPosition)
                            Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show()

                            // Notify FragmentSaved that a status was deleted
                            val resultIntent = Intent()
                            resultIntent.putExtra("status_deleted", true)
                            (context as Activity).setResult(Activity.RESULT_OK, resultIntent)
                        } else {
                            Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    val downloadImage = if (mediaModel.isDownloaded) {
                        R.drawable.ic_downloaded
                    } else {
                        R.drawable.ic_download
                    }
                    tools.statusDownload.setImageResource(downloadImage)

                    tools.download.setOnClickListener {
                        val isDownloaded = context.saveStatus(mediaModel)
                        if (isDownloaded) {
                            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
                            mediaModel.isDownloaded = true
                            tools.statusDownload.setImageResource(R.drawable.ic_downloaded)
                        } else {
                            Toast.makeText(context, "Unable to Save", Toast.LENGTH_SHORT).show()
                        }
                    }
                    tools.repost.setOnClickListener {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*" // Change type based on media type
                            putExtra(Intent.EXTRA_STREAM, mediaModel.pathUri.toUri())
                            setPackage("com.whatsapp") // Directly open WhatsApp
                        }
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                        }
                    }
                    tools.share.setOnClickListener {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*" // Adjust based on media type
                            putExtra(Intent.EXTRA_STREAM, mediaModel.pathUri.toUri())
                        }
                        context.startActivity(Intent.createChooser(intent, "Share via"))
                    }
                }
            }
        }

        fun stopPlayer() {
            binding.playerView.player?.stop()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemVideoPreviewBinding.inflate(
                LayoutInflater.from(context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.bind(model)
    }

    override fun getItemCount() = list.size
}
