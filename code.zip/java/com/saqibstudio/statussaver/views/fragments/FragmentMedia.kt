package com.saqibstudio.statussaver.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.saqibstudio.statussaver.data.StatusRepo
import com.saqibstudio.statussaver.databinding.FragmentMediaBinding
import com.saqibstudio.statussaver.models.MediaModel
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.viewmodels.factories.StatusViewModel
import com.saqibstudio.statussaver.viewmodels.factories.StatusViewModelFactory
import com.saqibstudio.statussaver.views.adapters.MediaAdapter

class FragmentMedia : Fragment() {
    private var _binding: FragmentMediaBinding? = null
    private val binding get() = _binding!! // Safe due to view lifecycle checks

    lateinit var viewModel: StatusViewModel
    lateinit var adapter: MediaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize ViewModel once for the fragment
        val repo = StatusRepo(requireActivity())
        viewModel = ViewModelProvider(
            requireActivity(),
            StatusViewModelFactory(repo)
        )[StatusViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMediaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let { args ->
            val mediaType = args.getString(Constants.MEDIA_TYPE_KEY, "")

            // Observe data with view lifecycle awareness
            when (mediaType) {
                Constants.MEDIA_TYPE_WHATSAPP_IMAGES -> {
                    viewModel.whatsAppImagesLiveData.observe(viewLifecycleOwner) { unFilteredList ->
                        if (activity == null) return@observe // Critical check
                        updateUI(unFilteredList)
                    }
                }
                Constants.MEDIA_TYPE_WHATSAPP_VIDEOS -> {
                    viewModel.whatsAppVideosLiveData.observe(viewLifecycleOwner) { unFilteredList ->
                        if (activity == null) return@observe
                        updateUI(unFilteredList)
                    }
                }
                Constants.MEDIA_TYPE_WHATSAPP_BUSINESS_IMAGES -> {
                    viewModel.whatsAppBusinessImagesLiveData.observe(viewLifecycleOwner) { unFilteredList ->
                        if (activity == null) return@observe
                        updateUI(unFilteredList)
                    }
                }
                Constants.MEDIA_TYPE_WHATSAPP_BUSINESS_VIDEOS -> {
                    viewModel.whatsAppBusinessVideosLiveData.observe(viewLifecycleOwner) { unFilteredList ->
                        if (activity == null) return@observe
                        updateUI(unFilteredList)
                    }
                }
            }
        }
    }

    private fun updateUI(unFilteredList: List<MediaModel>) {
        val filteredList = unFilteredList.distinctBy { it.fileName }
        val list = ArrayList(filteredList)

        adapter = MediaAdapter(list, requireContext()) // Safer than requireActivity()
        binding.mediaRecyclerView.adapter = adapter
        binding.tempMediaText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Prevent memory leaks
    }
}