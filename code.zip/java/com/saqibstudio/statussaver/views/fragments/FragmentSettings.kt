package com.saqibstudio.statussaver.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.saqibstudio.statussaver.R
import com.saqibstudio.statussaver.utils.SharedPrefUtils
import com.saqibstudio.statussaver.databinding.FragmentSettingsBinding
import com.saqibstudio.statussaver.models.SettingsModel
import com.saqibstudio.statussaver.utils.SharedPrefKeys
import com.saqibstudio.statussaver.views.adapters.SettingsAdapter


class FragmentSettings : Fragment() {
    private val binding by lazy {
        FragmentSettingsBinding.inflate(layoutInflater)
    }
    private val list = ArrayList<SettingsModel>()
    private val adapter by lazy {
        SettingsAdapter(list, requireActivity())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding.apply {

            binding.switchAutoSave.isChecked = SharedPrefUtils.getPrefBoolean(
                SharedPrefKeys.AUTO_SAVE,
                false
            )
            binding.switchAutoSave.setOnCheckedChangeListener { _, isChecked ->
                SharedPrefUtils.putPrefBoolean(
                    SharedPrefKeys.AUTO_SAVE,
                    isChecked
                )
                Toast.makeText(requireContext(),
                    "Auto Save ${if (isChecked) "Enabled" else "Disabled"}",
                    Toast.LENGTH_SHORT).show()
            }

        settingsRecyclerView.adapter = adapter

            list.add(
                SettingsModel(
                    title = "How to use",
                    desc = "Read how to us this app"
                )
            )
            list.add(
                SettingsModel(
                    title = "Save in Folder",
                    desc = "/internalstorage/Documents/${getString(R.string.app_name)}"
                )
            )
            list.add(
                SettingsModel(
                    title = "Disclaimer",
                    desc = "Read Our Disclaimer"
                )
            )
            list.add(
                SettingsModel(
                    title = "Privacy Policy",
                    desc = "Read Our Terms & Conditions"
                )
            )
            list.add(
                SettingsModel(
                    title = "Share",
                    desc = "Share this amazing app with you friends"
                )
            )
            list.add(
                SettingsModel(
                    title = "Rate Us",
                    desc = "If you like our product support us on play store"
                )
            )
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = binding.root
}