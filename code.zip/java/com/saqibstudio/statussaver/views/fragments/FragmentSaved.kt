package com.saqibstudio.statussaver.views.fragments

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.saqibstudio.statussaver.databinding.FragmentSavedBinding
import com.saqibstudio.statussaver.utils.getSavedStatuses
import com.saqibstudio.statussaver.views.adapters.MediaAdapter

class FragmentSaved : Fragment() {
    private var _binding: FragmentSavedBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: MediaAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSavedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        loadSavedStatuses()
    }

    // New addition: Refresh when fragment becomes visible
    override fun onResume() {
        super.onResume()
        loadSavedStatuses()
    }

    private fun setupRecyclerView() {
        adapter = MediaAdapter(ArrayList(), requireContext(), isSavedFragment = true)
        binding.savedRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.savedRecyclerView.adapter = adapter
    }

    private fun loadSavedStatuses() {
        val savedList = requireContext().getSavedStatuses()
        binding.emptyView.visibility = if (savedList.isEmpty()) View.VISIBLE else View.GONE
        adapter.updateList(savedList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 200 && resultCode == Activity.RESULT_OK) {
            val isDeleted = data?.getBooleanExtra("status_deleted", false) ?: false
            if (isDeleted) {
                loadSavedStatuses() // Existing refresh trigger
            }
        }
    }
}