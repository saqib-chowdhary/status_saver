package com.saqibstudio.statussaver.views.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.tabs.TabLayoutMediator
import com.saqibstudio.statussaver.data.StatusRepo
import com.saqibstudio.statussaver.databinding.FragmentStatusBinding
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.utils.SharedPrefKeys
import com.saqibstudio.statussaver.utils.SharedPrefUtils
import com.saqibstudio.statussaver.utils.getFolderPermissions
import com.saqibstudio.statussaver.viewmodels.factories.StatusViewModel
import com.saqibstudio.statussaver.viewmodels.factories.StatusViewModelFactory
import com.saqibstudio.statussaver.views.adapters.MediaViewPagerAdapter

class FragmentStatus : Fragment() {
    private var _binding: FragmentStatusBinding? = null
    private val binding get() = _binding!!

    // Handler for refresh timeout management
    private val refreshHandler = Handler(Looper.getMainLooper())
    private var refreshRunnable: Runnable? = null

    private lateinit var type: String
    private val WHATSAPP_REQUEST_CODE = 101
    private val WHATSAPP_BUSINESS_REQUEST_CODE = 102

    private val viewPagerTitles = arrayListOf("Images", "Videos")
    lateinit var viewModel: StatusViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = StatusRepo(requireActivity())
        viewModel = ViewModelProvider(
            requireActivity(),
            StatusViewModelFactory(repo)
        )[StatusViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStatusBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            type = it.getString(Constants.FRAGMENT_TYPE_KEY, "")

            setupViewPager()
            handleFragmentTypeLogic()
        }
    }

    private fun setupViewPager() {
        binding.statusViewPager.adapter = null
        val viewPagerAdapter = when (type) {
            Constants.TYPE_WHATSAPP_MAIN -> MediaViewPagerAdapter(requireActivity())
            Constants.TYPE_WHATSAPP_BUSINESS -> MediaViewPagerAdapter(
                requireActivity(),
                imagesType = Constants.MEDIA_TYPE_WHATSAPP_BUSINESS_IMAGES,
                videosType = Constants.MEDIA_TYPE_WHATSAPP_BUSINESS_VIDEOS
            )
            else -> MediaViewPagerAdapter(requireActivity())
        }
        binding.statusViewPager.adapter = viewPagerAdapter

        TabLayoutMediator(binding.tabLayout, binding.statusViewPager) { tab, pos ->
            tab.text = viewPagerTitles[pos]
        }.attach()
    }

    private fun handleFragmentTypeLogic() {
        val isPermissionGranted = when (type) {
            Constants.TYPE_WHATSAPP_MAIN -> SharedPrefUtils.getPrefBoolean(
                SharedPrefKeys.PREF_KEY_WP_PERMISSION_GRANTED,
                false
            )
            else -> SharedPrefUtils.getPrefBoolean(
                SharedPrefKeys.PREF_KEY_WP_BUSINESS_PERMISSION_GRANTED,
                false
            )
        }

        if (isPermissionGranted) {
            loadInitialData()
            setupRefreshListener()
        }
        setupPermissionButton()
    }

    private fun loadInitialData() {
        when (type) {
            Constants.TYPE_WHATSAPP_MAIN -> getWhatsAppStatuses()
            Constants.TYPE_WHATSAPP_BUSINESS -> getWhatsAppBusinessStatuses()
        }
    }

    private fun setupRefreshListener() {
        binding.swipeRefreshLayout.setOnRefreshListener {
            refreshStatuses()
        }
    }

    private fun setupPermissionButton() {
        binding.permissionLayout.btnPermission.setOnClickListener {
            getFolderPermissions(
                context = requireActivity(),
                REQUEST_CODE = when (type) {
                    Constants.TYPE_WHATSAPP_MAIN -> WHATSAPP_REQUEST_CODE
                    else -> WHATSAPP_BUSINESS_REQUEST_CODE
                },
                initialUri = when (type) {
                    Constants.TYPE_WHATSAPP_MAIN -> Constants.getWhatsappUri()
                    else -> Constants.getWhatsappBusinessUri()
                }
            )
        }
    }

    private fun refreshStatuses() {
        // Cancel any pending refresh operations
        cancelPendingRefresh()

        when (type) {
            Constants.TYPE_WHATSAPP_MAIN -> {
                Toast.makeText(requireActivity(), "Refreshing WP Statuses", Toast.LENGTH_SHORT).show()
                getWhatsAppStatuses()
            }
            else -> {
                Toast.makeText(requireActivity(), "Refreshing WP Business Statuses", Toast.LENGTH_SHORT).show()
                getWhatsAppBusinessStatuses()
            }
        }

        // Post new refresh completion handler
        refreshRunnable = Runnable {
            if (isAdded && _binding != null) {
                binding.swipeRefreshLayout.isRefreshing = false
            }
        }
        refreshHandler.postDelayed(refreshRunnable!!, 2000)
    }

    private fun cancelPendingRefresh() {
        refreshRunnable?.let {
            refreshHandler.removeCallbacks(it)
            refreshRunnable = null
        }
    }

    private fun getWhatsAppStatuses() {
        binding.permissionLayoutHolder.visibility = View.GONE
        viewModel.getWhatsAppStatuses()
    }

    private fun getWhatsAppBusinessStatuses() {
        binding.permissionLayoutHolder.visibility = View.GONE
        viewModel.getWhatsAppBusinessStatuses()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Critical cleanup to prevent memory leaks
        cancelPendingRefresh()
        _binding = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == AppCompatActivity.RESULT_OK && data?.data != null) {
            val treeUri = data.data!!
            requireActivity().contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )

            when (requestCode) {
                WHATSAPP_REQUEST_CODE -> {
                    SharedPrefUtils.putPrefString(
                        SharedPrefKeys.PREF_KEY_WP_TREE_URI,
                        treeUri.toString()
                    )
                    SharedPrefUtils.putPrefBoolean(SharedPrefKeys.PREF_KEY_WP_PERMISSION_GRANTED, true)
                    getWhatsAppStatuses()
                }
                WHATSAPP_BUSINESS_REQUEST_CODE -> {
                    SharedPrefUtils.putPrefString(
                        SharedPrefKeys.PREF_KEY_WP_BUSINESS_TREE_URI,
                        treeUri.toString()
                    )
                    SharedPrefUtils.putPrefBoolean(
                        SharedPrefKeys.PREF_KEY_WP_BUSINESS_PERMISSION_GRANTED,
                        true
                    )
                    getWhatsAppBusinessStatuses()
                }
            }
        }
    }
}