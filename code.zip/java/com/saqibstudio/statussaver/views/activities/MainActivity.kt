package com.saqibstudio.statussaver.views.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.saqibstudio.statussaver.R
import com.saqibstudio.statussaver.databinding.ActivityMainBinding
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.utils.SharedPrefKeys
import com.saqibstudio.statussaver.utils.SharedPrefUtils
import com.saqibstudio.statussaver.utils.replaceFragment
import com.saqibstudio.statussaver.utils.slideFromStart
import com.saqibstudio.statussaver.utils.slideToEndWithFadeOut
import com.saqibstudio.statussaver.views.fragments.FragmentSaved
import com.saqibstudio.statussaver.views.fragments.FragmentSettings
import com.saqibstudio.statussaver.views.fragments.FragmentStatus


class MainActivity : AppCompatActivity() {
    private val activity = this
    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        SharedPrefUtils.init(activity)
        MobileAds.initialize(this)
        binding.apply {
            setSupportActionBar(binding.toolBar)
            val adRequest = AdRequest.Builder().build()
            adView.loadAd(adRequest)
            requestPermission()
            val fragmentWhatsAppStatus = FragmentStatus()
            val bundle = Bundle()
            bundle.putString(Constants.FRAGMENT_TYPE_KEY, Constants.TYPE_WHATSAPP_MAIN)
            replaceFragment(fragmentWhatsAppStatus, bundle)
            toolBar.setNavigationOnClickListener {
                drawerLayout.open()
            }
            navigationView.setNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.drawer_menu_status -> {
                        // whatsapp status
                        val fragmentWhatsAppStatus = FragmentStatus()
                        val bundle = Bundle()
                        bundle.putString(Constants.FRAGMENT_TYPE_KEY, Constants.TYPE_WHATSAPP_MAIN)
                        replaceFragment(fragmentWhatsAppStatus, bundle)
                        drawerLayout.close()
                    }

                    R.id.drawer_menu_business_status -> {
                        // whatsapp business status
                        val fragmentWhatsAppStatus = FragmentStatus()
                        val bundle = Bundle()
                        bundle.putString(
                            Constants.FRAGMENT_TYPE_KEY,
                            Constants.TYPE_WHATSAPP_BUSINESS
                        )
                        replaceFragment(fragmentWhatsAppStatus, bundle)
                        drawerLayout.close()
                    }

                    R.id.drawer_menu_settings -> {
                        // settings
                        replaceFragment(FragmentSettings())
                        drawerLayout.close()
                    }
                    R.id.menu_shareapp ->{
                        shareApp()
                    }
                    R.id.saved ->{
                        replaceFragment(FragmentSaved())
                        drawerLayout.close()
                    }
                    R.id.menu_rate ->{
                        rateApp()
                    }
                    R.id.menu_privacy ->{
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://developerdojo8111.blogspot.com/2024/07/privacy-policy-status-saver.html")).apply {
                            startActivity(this)
                        }
                    }
                    R.id.qr_ad ->{
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.saqibstudio.codescanner")).apply {
                            startActivity(this)
                        }
                    }
                }

                return@setNavigationItemSelectedListener true
            }

        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)

                if (currentFragment is FragmentStatus) {
                    showExitDialog() // Show exit dialog if user is in FragmentStatus
                } else {
                    // Navigate back to FragmentStatus
                    val fragmentWhatsAppStatus = FragmentStatus()
                    val bundle = Bundle()
                    bundle.putString(Constants.FRAGMENT_TYPE_KEY, Constants.TYPE_WHATSAPP_MAIN)
                    replaceFragment(fragmentWhatsAppStatus, bundle, false)
                }
            }
        })
    }

    private val PERMISSION_REQUEST_CODE = 50
    private fun requestPermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            val isPermissionsGranted = SharedPrefUtils.getPrefBoolean(
                SharedPrefKeys.PREF_KEY_IS_PERMISSIONS_GRANTED,
                false
            )
            if (!isPermissionsGranted) {
                ActivityCompat.requestPermissions(
                    /* activity = */ activity,
                    /* permissions = */ arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    /* requestCode = */ PERMISSION_REQUEST_CODE
                )
                Toast.makeText(activity, "Please Grant Permissions", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val isGranted = grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (isGranted) {
                SharedPrefUtils.putPrefBoolean(SharedPrefKeys.PREF_KEY_IS_PERMISSIONS_GRANTED, true)
            } else {
                SharedPrefUtils.putPrefBoolean(
                    SharedPrefKeys.PREF_KEY_IS_PERMISSIONS_GRANTED,
                    false
                )

            }
        }
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val fragment = supportFragmentManager?.findFragmentById(R.id.fragment_container)
        fragment?.onActivityResult(requestCode, resultCode, data)
    }
    private fun rateApp() {
        val appPackageName = packageName
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$appPackageName"))
            startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName"))
            startActivity(intent)
        }
    }
    private fun showExitDialog() {
        val dialogView = layoutInflater.inflate(R.layout.exit_dialogue, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        val nativeAdView = dialogView.findViewById<NativeAdView>(R.id.nativeAdView)
        val btnExit = dialogView.findViewById<Button>(R.id.btnExit)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        // Load Native Ad
        val adLoader = AdLoader.Builder(this, getString(R.string.native_id))
            .forNativeAd { nativeAd ->
                populateNativeAdView(nativeAd, nativeAdView)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e("AdMob", "Native Ad Failed to Load: ${error.message}")
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())

        // Handle button clicks
        btnExit.setOnClickListener {
            finishAffinity() // Exit app
        }

        btnCancel.setOnClickListener {
            dialog.dismiss() // Dismiss dialog
        }

        dialog.show()
    }
    fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        // Set the headline (Required field)
        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        headlineView.text = nativeAd.headline
        adView.headlineView = headlineView

        // Set the body text (Optional field)
        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (nativeAd.body != null) {
            bodyView.text = nativeAd.body
            bodyView.visibility = View.VISIBLE
        } else {
            bodyView.visibility = View.GONE
        }
        adView.bodyView = bodyView

        // Set the ad icon (Check for null)
        val adIconView = adView.findViewById<ImageView>(R.id.ad_icon)
        val icon = nativeAd.icon
        if (icon != null) {
            adIconView.setImageDrawable(icon.drawable)
            adIconView.visibility = View.VISIBLE
        } else {
            adIconView.visibility = View.GONE
        }
        adView.iconView = adIconView

        // Set the Call-to-Action button (Optional)
        val ctaButton = adView.findViewById<Button>(R.id.ad_call_to_action)
        if (nativeAd.callToAction != null) {
            ctaButton.text = nativeAd.callToAction
            ctaButton.visibility = View.VISIBLE
        } else {
            ctaButton.visibility = View.GONE
        }
        adView.callToActionView = ctaButton

        // Register the NativeAdView
        adView.setNativeAd(nativeAd)
    }



    private fun shareApp() {
        val appPackageName = packageName
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Check out this amazing app: https://play.google.com/store/apps/details?id=$appPackageName")
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.bottom_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.iamsettings -> {replaceFragment(FragmentSettings())}
        }
        return super.onOptionsItemSelected(item)
    }
}










