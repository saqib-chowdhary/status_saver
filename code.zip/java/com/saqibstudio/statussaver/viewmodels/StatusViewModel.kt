package com.saqibstudio.statussaver.viewmodels.factories

import android.util.Log
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.saqibstudio.statussaver.data.StatusRepo
import com.saqibstudio.statussaver.models.MEDIA_TYPE_IMAGE
import com.saqibstudio.statussaver.models.MEDIA_TYPE_VIDEO
import com.saqibstudio.statussaver.models.MediaModel
import com.saqibstudio.statussaver.utils.Constants
import com.saqibstudio.statussaver.utils.SharedPrefKeys
import com.saqibstudio.statussaver.utils.SharedPrefUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatusViewModel(val repo: StatusRepo) : ViewModel() {
    private val wpStatusLiveData get() = repo.whatsAppStatusesLiveData
    private val wpBusinessStatusLiveData get() = repo.whatsAppBusinessStatusesLiveData
    private val TAG = "StatusViewModel"

    // wp main
    val whatsAppImagesLiveData = MutableLiveData<ArrayList<MediaModel>>()
    val whatsAppVideosLiveData = MutableLiveData<ArrayList<MediaModel>>()

    // wp business
    val whatsAppBusinessImagesLiveData = MutableLiveData<ArrayList<MediaModel>>()
    val whatsAppBusinessVideosLiveData = MutableLiveData<ArrayList<MediaModel>>()

    private var isPermissionsGranted = false

    init {
        SharedPrefUtils.init(repo.context)

        val wpPermissions =
            SharedPrefUtils.getPrefBoolean(SharedPrefKeys.PREF_KEY_WP_PERMISSION_GRANTED, false)
        val wpBusinessPermissions = SharedPrefUtils.getPrefBoolean(
            SharedPrefKeys.PREF_KEY_WP_BUSINESS_PERMISSION_GRANTED,
            false
        )

        isPermissionsGranted = wpPermissions && wpBusinessPermissions
        Log.d(TAG, "Status View Model: isPermissions=> $isPermissionsGranted ")
        if (isPermissionsGranted) {
        Log.d(TAG, "Status View Model: Permissions Already Granted Getting Statuses ")
            CoroutineScope(Dispatchers.IO).launch {
                repo.getAllStatuses()

            }
            CoroutineScope(Dispatchers.IO).launch {
                repo.getAllStatuses(Constants.TYPE_WHATSAPP_BUSINESS)
            }
        }
    }

    fun getWhatsAppStatuses() {
        CoroutineScope(Dispatchers.IO).launch {
            if (!isPermissionsGranted) {
                Log.d(TAG, "getWhatsAppStatuses: Requesting WP Statuses")

                repo.getAllStatuses()
            }

            withContext(Dispatchers.Main){
                getWhatsAppImages()
                getWhatsAppVideos()
            }

        }
    }

    fun getWhatsAppImages() {
        wpStatusLiveData.observe(repo.activity as LifecycleOwner) {
            val tempList = ArrayList<MediaModel>(it) // Create a copy
            val filteredList = ArrayList<MediaModel>()

            tempList.forEach { mediaModel ->
                if (mediaModel.type == MEDIA_TYPE_IMAGE) {
                    filteredList.add(mediaModel)
                }
            }
            whatsAppImagesLiveData.postValue(filteredList)
        }
    }

    fun getWhatsAppVideos() {
        wpStatusLiveData.observe(repo.activity as LifecycleOwner) {
            val tempList = ArrayList<MediaModel>(it) // Create a copy to avoid modification issues
            val filteredList = ArrayList<MediaModel>()

            tempList.forEach { mediaModel ->
                if (mediaModel.type == MEDIA_TYPE_VIDEO) {
                    filteredList.add(mediaModel)
                }
            }
            whatsAppVideosLiveData.postValue(filteredList)
        }
    }



    fun getWhatsAppBusinessStatuses() {
        CoroutineScope(Dispatchers.IO).launch {
            if (!isPermissionsGranted) {
                Log.d(TAG, "getWhatsAppStatuses: Requesting WP Business Statuses")
                repo.getAllStatuses(Constants.TYPE_WHATSAPP_BUSINESS)
            }

            withContext(Dispatchers.Main){
                getWhatsAppBusinessImages()
                getWhatsAppBusinessVideos()
            }

        }
    }

    fun getWhatsAppBusinessImages() {
        wpBusinessStatusLiveData.observe(repo.activity as LifecycleOwner) {
            val tempList = ArrayList<MediaModel>(it) // Create a copy
            val filteredList = ArrayList<MediaModel>()

            tempList.forEach { mediaModel ->
                if (mediaModel.type == MEDIA_TYPE_IMAGE) {
                    filteredList.add(mediaModel)
                }
            }
            whatsAppBusinessImagesLiveData.postValue(filteredList)
        }
    }

    fun getWhatsAppBusinessVideos() {
        wpBusinessStatusLiveData.observe(repo.activity as LifecycleOwner) {
            val tempList = ArrayList<MediaModel>(it) // Create a copy
            val filteredList = ArrayList<MediaModel>()

            tempList.forEach { mediaModel ->
                if (mediaModel.type == MEDIA_TYPE_VIDEO) {
                    filteredList.add(mediaModel)
                }
            }
            whatsAppBusinessVideosLiveData.postValue(filteredList)
        }
    }



}












